package javawork6_18;

import java.io.IOException;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) throws IOException {
		Count c = new Count();
		Scanner s = new Scanner(System.in);
		System.out.println("请输入文件名：");
		String fileName = s.nextLine();
		c.count(fileName);
		
		System.out.println( "文件名：" + fileName );
		System.out.println("字符数：" + c.word);
		System.out.println("单词数："+c.space);
		System.out.println("行数："+c.line);
	}

}
