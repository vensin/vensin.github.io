package javawork6_18;

import java.io.*;
import java.util.regex.*;

public class Count {
	public int space = 0;  
	public int word= 0;
	public int line= 0;
	boolean count(String fileName) throws IOException{
		//File f = new File(fileName);
		String s = null;
		BufferedReader re = new BufferedReader(new FileReader(fileName));
		while(null != (s = re.readLine())) {
			line ++; 
			word += countWord(s);
			space += countSpace(s);
		}
		re.close();
		return true;
		
	}
	
	 public int countWord(String str) {
	        int count = 0;
	        Pattern p = Pattern.compile("[^\\s]");
	        Matcher m = p.matcher(str);
	        while(m.find()){
	            count++;
	        }
	        return count;
	    }
	public int countSpace(String str) {
//		int count = 0;
//		Pattern p = Pattern.compile("(^[^\\s]+$)|([\\s]+[^\\s]+)|([^\\s]+[\\s]+)");
//		Matcher m = p.matcher(str);
//		while(m.find()){
//			System.out.println("oneword");
//            count++;
//        }
		String[] num = str.split("\\s+");
		return num.length;
	}

}
