package javawork4;

public class ProveEmail {
	boolean proveEmail(String email) {
		String str = "^([a-zA-Z0-9_\\-\\.]+\\@[a-zA-Z0-9_\\-\\.]+\\.[a-zA-Z]{2,4}$)";
		return email.matches(str);
		
	}
}
