package javawork4;

public class TestEmail {
	
	public static void main(String[] args) {
		ProveEmail test = new ProveEmail();
		
		String[] emails ={"8364287389@qq.com","836.4_89@qq.com","83-4287389@qq.com",
				"8364287389qq.com","8364287389@qqcom","8364287389@qq.com34"};

		for(String email : emails) {
			
			System.out.println(test.proveEmail(email));
		}
		
		
	}
}
