package javawork6_16;

import java.io.*;

public class Input {
	public File f = new File(".\\src\\javawork16","write.txt");
	
	boolean write() throws IOException {
		BufferedReader btin = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter btout = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f)));
		String s = null;
		
		System.out.println("请开始输入");
		while(!(s = btin.readLine()).equals("quit")) {
			btout.write(s);
			btout.newLine();
		}
		System.out.println("输入结束");
		
		btout.flush();
		btin.close();
		btout.close();
		return true;
	}
	
}
