package javawork6_16;

import java.io.IOException;

public class Test {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Input in = new Input();
		in.write();
	}

}
