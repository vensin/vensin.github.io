package javawork6_17;

import java.io.IOException;

public class Test {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Delete de = new Delete();
		de.deleteString("");
	}

}
