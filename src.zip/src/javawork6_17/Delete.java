package javawork6_17;

import java.io.*;
import java.util.Scanner;

public class Delete {
	boolean deleteString(String str) throws IOException {

		BufferedReader re = null;
		String s = null;
		PrintWriter p = null;
		try {
			re = new BufferedReader(new FileReader("E:\\test.txt"));
			StringBuilder sb = new StringBuilder();
			while(null != (s = re.readLine())) {
				s = s.replace("John", "");
				sb.append(s + "\n\r");
			}
			p = new PrintWriter(new FileOutputStream(new File("E:\\test.txt")));
			p.write(sb.toString());
			return true;
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			re.close();
			p.close();
			
		}
		
		return false;
		
	}
}
