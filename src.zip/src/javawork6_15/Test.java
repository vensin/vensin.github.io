package javawork6_15;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		
		System.out.println("请输入源文件文件名");
		String oldFileName = input.nextLine();
		System.out.println("请输入目标文件文件名");
		String newFileName = input.nextLine();
		
		Copy copy = new Copy();
		if(copy.copy(oldFileName, newFileName)) {
			System.out.println("复制文件成功");
		}
}

}
