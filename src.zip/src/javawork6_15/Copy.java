package javawork6_15;

import java.io.*;

public class Copy {
	FileInputStream fis = null;
	FileOutputStream fos = null;
	boolean copy(String oldFileName,String newFileName) {
		try {
			fis = new FileInputStream(".\\src\\javawork15\\" +oldFileName);
			fos = new FileOutputStream(newFileName);
			
			int a;
		
				while((a = fis.read()) != -1) {
					fos.write(a);
				}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			try {
				fis.close();
				fos.close();
				return true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return false;
		
		
	}
}
