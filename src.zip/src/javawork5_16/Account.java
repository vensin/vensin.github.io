package javawork5_16;

public class Account {
	public String name;
	public long money;
	
	Account(String name,long money){
		this.name = name;
		this.money = money;
		
		System.out.println(name+"账户余额为"+money);
	}
}
