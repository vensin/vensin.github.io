package javawork5_16;

public class TestSave {

	public static void main(String[] args) {
		Save a = new Save("用户1");
		Save b = new Save("用户2");
		
		a.start();
		b.start();
	}

}
