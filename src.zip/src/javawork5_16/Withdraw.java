package javawork5_16;

public class Withdraw {
	boolean withdraw(Account people,long money) {
		if(people.money >= money) {
			people.money -= money;
			System.out.println(people.name+"取款"+money+"成功。"+"账户余额为："+people.money);
	
			return true;
		}
		else {
			System.out.println(people.name+"取款"+money+"失败。"+"账户余额为："+people.money);
		
			return false;
		}
		
	}
}
