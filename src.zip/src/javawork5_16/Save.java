package javawork5_16;

public class Save extends Thread{
	
	public Save(String people) {
        super(people);
	}
	
	public void run() {
		Account people = new Account(getName(),0);
		
		Deposit save = new Deposit();
		for(int i =1;i<=3;i++ ) {
			save.deposit(people,100);
			System.out.println(people.name+"汇款总额为" + 100*i);
		}
	}



}
