package javawork5_16;

public class TestAtm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bank a= new Bank("用户1");
		Bank b= new Bank("用户2");
		
		a.start();
		b.start();
	}

}
