package javawork5_16;

public class Bank extends Thread{
	
	public Bank(String people) {
        super(people);
	}
	
	public void run(){
		Account people = new Account(getName(),1000);
		Deposit save = new Deposit();
		Withdraw get = new Withdraw();
		int flag=0;
		for(int i =1;i<=5;i++ ) {
			flag = (int) Math.random();
			long money = (long)( (Math.random()*500) + 500);
			if(flag>=0.5) {
				save.deposit(people, money);
			}else {
				get.withdraw(people, money);
			}
			
			 try {
				 sleep((long) (2000*Math.random()));//休息一秒
			} catch (InterruptedException e) {
				  e.printStackTrace();
			}
			
		}
	}
}
