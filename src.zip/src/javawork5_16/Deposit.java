package javawork5_16;

public class Deposit {
	boolean deposit(Account people,long money) {
		
			people.money += money;
			System.out.println(people.name+"存款成功。"+"账户余额为："+people.money);
	
			return true;

	}
}
