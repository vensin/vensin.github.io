package javawork5_15;

public class Station extends Thread{
	static int tick = 20;//总票数
	
	public Station(String name) {
        super(name);
   }
	public void run() {
		while(tick>0) {
			
			if(tick>0) {
				tick--;
				System.out.println(getName() +"卖出了一张票，余票" + tick);
				
			}
			
			 try {
				 sleep((long) (2000*Math.random()));//休息一秒
			} catch (InterruptedException e) {
				  e.printStackTrace();
			}
			
		}
		System.out.println("票已售完");
	}
}
