package javawork5_15;

public class TestSale {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Station station1=new Station("窗口1");
        Station station2=new Station("窗口2");
        Station station3=new Station("窗口3");
        station1.start();
        station2.start();
        station3.start();
	}

}
